var rounded = Math.round(1.5);
console.log(rounded);

# 000-Selectors
***

## Goal: Practice using CSS selectors to style HTML elements.

*Instructions:*

Open the `index.html` in your browser using `$ open index.html` in the terminal.

Note: From now on, `$` will be used to denote code that should be run in the terminal,
though you don't have to actually type `$`.

Try to replicate the example image provided on the webpage by adding styling in your
`app.css` file using the `background-color` property. 

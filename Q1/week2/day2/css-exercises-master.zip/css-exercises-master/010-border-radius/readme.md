# 010-Border-Radius
***

## Goal: Use border-radius to create two circles and a rounded rectangle.

*Instructions:*

Try to replicate the three example images provided on the webpage by adding styling in your
`app.css` file using the `border-radius` property.

*Hint:* Read more about `border-radius` here: [http://www.css3.info/preview/rounded-border/]. You can ignore the moz/webkit stuff.

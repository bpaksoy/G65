# Responsive Blog

This blog uses fixed widths. Translate all widths to be fluid.

## Resources
* [Section on Flexible Images](http://css-tricks.com/rundown-of-handling-flexible-media/)

## Notes:
* Don't change the HTML.
* Consider using max-width for outer containers & images

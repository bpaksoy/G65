# CSS Exercises

1. CD into each directory
1. Look in *both* the HTML file and *README.md* in each folder for instructions
